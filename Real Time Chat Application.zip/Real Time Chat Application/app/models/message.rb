class Message < ApplicationRecord
end
