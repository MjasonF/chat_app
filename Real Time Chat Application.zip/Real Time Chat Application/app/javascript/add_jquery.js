import jquery from "jquery";

window.jQuery = jquery;

window.$ = jquery;